<div class="card bg-base-100 w-96 shadow-xl my-5">
    <figure>
        <img
        src="https://placehold.co/350x200"
        alt="Shoes" />
    </figure>
    <div class="card-body">
        <h2 class="card-title text-4xl">
        Here is the title
        <div class="badge badge-secondary">NEW</div>
        </h2>
        <p>If a dog chews shoes whose shoes does he choose?</p>
        <div class="card-actions justify-end">
            <div class="badge badge-outline">Date:</div>
            <div class="badge badge-outline">Authoor</div>
        </div>
    </div>
</div>