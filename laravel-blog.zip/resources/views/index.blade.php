<x-layout>
<section class="lg:grid lg:grid-cols-3 max-w-[90%] m-auto">
    <x-card/>
    <x-card/>
    <x-card/>
</section>
</x-layout>

